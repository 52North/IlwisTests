#ifndef CORETEST_GLOBAL_H
#define CORETEST_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(CORETEST_LIBRARY)
#  define CORETESTSHARED_EXPORT Q_DECL_EXPORT
#else
#  define CORETESTSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // CORETEST_GLOBAL_H
