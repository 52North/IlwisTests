#include "coretest.h"


//void runTests() {

//}

CoreTest::CoreTest()
{
}
